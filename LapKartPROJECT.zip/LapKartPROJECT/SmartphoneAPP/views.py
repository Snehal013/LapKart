from django.contrib.auth import login,logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import render,redirect
from .forms import SmartphoneModelForm
from .models import Smartphone


# Create your views here.
def test_view(request):
    template_name="SmartphoneAPP/slayout.html"
    context={}
    return render(request, template_name, context)

@login_required(login_url="/auth/login")
def show_smartphone_view(request):
    qs_of_smartphone=Smartphone.objects.all()
    template_name="SmartphoneAPP/show_smartphone.html"
    context={"qs_of_smartphone":qs_of_smartphone}
    return render(request, template_name, context)

@login_required(login_url="/auth/login")
def add_smartphone_view(request):
    form=SmartphoneModelForm()
    if request.method=="POST":
        form=SmartphoneModelForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/smartphone/show/")
    template_name="SmartphoneAPP/add_smartphone.html"
    context={"form":form}
    return render(request, template_name, context)

def update_view(request,i):
    smart_obj=Smartphone.objects.get(id=i)
    form = SmartphoneModelForm(instance=smart_obj)
    if request.method == "POST":
        form = SmartphoneModelForm(request.POST,instance=smart_obj)
        if form.is_valid():
            form.save()
            return redirect("/smartphone/show/")
    template_name = "SmartphoneAPP/add_smartphone.html"
    context = {"form":form}
    return render(request, template_name, context)

def delete_view(request,i):
    smart_obj = Smartphone.objects.get(id=i)
    smart_obj.delete()
    return redirect("/smartphone/show/")