from django.urls import path
from .import views
urlpatterns=[
    path("test/",views.test_view),
    path("show/",views.show_smartphone_view),
    path("add/",views.add_smartphone_view),
    path("update/<i>/",views.update_view),
    path("delete/<i>/",views.delete_view),
]