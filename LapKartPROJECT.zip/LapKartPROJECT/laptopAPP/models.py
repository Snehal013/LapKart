from django.db import models


# Create your models here.
class Laptop(models.Model):
    id=models.IntegerField(primary_key=True)
    company=models.CharField(max_length=32)
    varient=models.CharField(max_length=32)
    ram=models.IntegerField()
    rom=models.IntegerField()
    price=models.FloatField()