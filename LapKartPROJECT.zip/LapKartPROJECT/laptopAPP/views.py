from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.shortcuts import render,redirect
from .forms import LaptopModelForm
from .models import Laptop


# Create your views here.
def test_view(request):
    template_name="laptopAPP/layout.html"
    context={}
    return render(request, template_name, context)

@login_required(login_url="/auth/login")
def show_laptop_view(request):
    qs_of_laptops=Laptop.objects.all()
    template_name="laptopAPP/show_laptop.html"
    context={"qs_of_laptops":qs_of_laptops}
    return render(request, template_name, context)

@login_required(login_url="/auth/login")
def add_laptop_view(request):
    form=LaptopModelForm()
    if request.method=="POST":
        form=LaptopModelForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/laptops/show/")
    template_name="laptopAPP/add_laptop.html"
    context={"form":form}
    return render(request, template_name, context)

def update_laptop_view(request,i):
    lap_obj=Laptop.objects.get(id=i)
    form = LaptopModelForm(instance=lap_obj)
    if request.method == "POST":
        form = LaptopModelForm(request.POST,instance=lap_obj)
        if form.is_valid():
            form.save()
            return redirect("/laptops/show/")
    template_name = "laptopAPP/add_laptop.html"
    context = {"form": form}
    return render(request, template_name, context)

def delete_laptop_view(request,i):
    lap_obj=Laptop.objects.get(id=i)
    lap_obj.delete()
    return redirect("/laptops/show/")