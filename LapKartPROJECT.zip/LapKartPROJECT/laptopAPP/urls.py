from django.urls import path
from .import views
urlpatterns=[
    path("test/",views.test_view),
    path("show/",views.show_laptop_view),
    path("add/",views.add_laptop_view),
    path("update/<i>",views.update_laptop_view),
    path("delete/<i>",views.delete_laptop_view),
]